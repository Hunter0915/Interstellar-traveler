<!DOCTYPE html>
<html>
<head>
	<title>Главная</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta charset="utf-8">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
	<link rel="stylesheet" href="css/style.css">
</head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<body class="bg-dark">
	<div class="col-12 bg-dark" style="height: 60px;">
		<div class="row">
			<h1 class="text-white ml-3 p-1">Interstellar traveler</h1>
			<div class="wrapper p-2">
			  <div class="container">
			    <input type="text" class="input" placeholder="Search">
			    <i class="fa fa-search" aria-hidden="true"></i>
			  </div>
			</div>
			<a href="admin.php" style="margin-left: 40%"><h3 class="text-white p-3">Add goods</h3></a>
			<h3 class="text-white p-3" >Login</h3>
			<h3 class="text-white p-3" >Join</h3>
		</div>
	</div>
	<div class="col-12" style="height: 600px; background-image: url(img/main.jpg); background-size: 100% 100%;">
		<h1 class="text-white" style="padding-left: 50%; padding-top: 15%">Everything YOU need for the conquerors of the universes</h1>
	</div>
	<div class="col-12 bg-dark mx-auto" style="height: 1200px;">
		<div class="row">
			<div class="col-3 mx-auto">
				<h3 class="text-white text-center">
					<?php
						$connect = mysqli_connect("127.0.0.1", "root", "", "Store");

						$zapros_text = "SELECT * FROM post";
						$zapros = mysqli_query($connect, $zapros_text);

						$result1 = $zapros->fetch_assoc();
						$result2 = $zapros->fetch_assoc();
						$result3 = $zapros->fetch_assoc();
						$result4 = $zapros->fetch_assoc();
						$result5 = $zapros->fetch_assoc();

						echo $result1["title"];
					?>
				</h3>
				<?php
					echo "<img class='w-100 rounded' src='{$result1['img']}'"
				?>
				<p class="text-white">
					<?php
						echo $result1["des"];
					?>
				</p>
				<p class="text-white text-center">
					<?php
						echo $result1["price"];
					?>
				</p>
			</div>
			<div class="col-3 mx-auto" style="height: 300px;">
				<h3 class="text-white text-center">
					<?php
						echo $result2["title"];
					?>
				</h3>
				<?php
					echo "<img class='w-100 rounded' src='{$result2['img']}'"
				?>
				<p class="text-white">
					<?php
						echo $result2["des"];
					?>
				</p>
				<p class="text-white text-center">
					<?php
						echo $result2["price"];
					?>
				</p>
			</div>
			<div class="col-3 mx-auto" style="height: 300px;">
				<h3 class="text-white text-center">
					<?php
						echo $result3["title"];
					?>
				</h3>
				<?php
					echo "<img class='w-100 rounded' src='{$result3['img']}'"
				?>
				<p class="text-white">
					<?php
						echo $result3["des"];
					?>
				</p>
				<p class="text-white text-center">
					<?php
						echo $result3["price"];
					?>
				</p>
			</div>
		</div>
		<div class="row">
			<div class="col-3 mx-auto mt-2">
				<h3 class="text-white text-center">
					<?php
						echo $result4["title"];
					?>
				</h3>
				<?php
					echo "<img class='w-100 rounded' src='{$result4['img']}'"
				?>
				<p class="text-white">
					<?php
						echo $result4["des"];
					?>
				</p>
				<p class="text-white text-center">
					<?php
						echo $result4["price"];
					?>
				</p>
			</div>
			<div class="col-3 mx-auto" style="height: 300px;">
				<h3 class="text-white text-center">
					<?php
						echo $result5["title"];
					?>
				</h3>
				<?php
					echo "<img class='w-100 rounded' src='{$result5['img']}'"
				?>
				<p class="text-white">
					<?php
						echo $result5["des"];
					?>
				</p>
				<p class="text-white text-center">
					<?php
						echo $result5["price"];
					?>
				</p>
			</div>
			<div class="col-3 mx-auto" style="height: 300px;">
				<h3 class="text-white text-center">
					<?php
						echo $result6["title"];
					?>
				</h3>
				<?php
					echo "<img class='w-100 rounded' src='{$result6['img']}'"
				?>
				<p class="text-white">
					<?php
						echo $result6["des"];
					?>
				</p>
				<p class="text-white text-center">
					<?php
						echo $result6["price"];
					?>
				</p>
			</div>
		</div>
	</div>
	<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
    <script  src="js/index.js"></script>
</body>
</html>