<?php
	$connect = mysqli_connect("127.0.0.1", "root", "", "Store");
	$zapros_text_insert = "INSERT INTO post (title, des, img, price) 
	VALUES ('{$_GET["title"]}', '{$_GET["des"]}', '{$_GET["img"]}', '{$_GET["price"]}')";
	$zapros_insert = mysqli_query($connect, $zapros_text_insert);
	function Redirect($url, $permanent = false)
	{
	    if (headers_sent() === false)
	    {
	        header('Location: ' . $url, true, ($permanent === true) ? 301 : 302);
	    }

	    exit();
	}

	Redirect('index.php', false);
?>