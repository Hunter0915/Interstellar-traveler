<?php
	$connect = mysqli_connect("127.0.0.1", "root", "", "Twitter");
	$zapros_text_insert = "INSERT INTO reader (user, link, img) 
	VALUES ('{$_GET["user"]}', '{$_GET["link"]}', '{$_GET["img"]}')";
	$zapros_insert = mysqli_query($connect, $zapros_text_insert);
	function Redirect($url, $permanent = false)
	{
	    if (headers_sent() === false)
	    {
	        header('Location: ' . $url, true, ($permanent === true) ? 301 : 302);
	    }

	    exit();
	}

	Redirect('index.php', false);
?>